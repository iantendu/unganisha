package com.example.unganisha;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FarmerProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_profile);
    }
}